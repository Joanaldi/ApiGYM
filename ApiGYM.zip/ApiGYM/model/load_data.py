import sqlite3
import json
from werkzeug.security import generate_password_hash

# Conectar a la base de datos
con = sqlite3.connect("datos.db")
cur = con.cursor()

# Crear la tabla User si no existe
cur.execute(
    """
    CREATE TABLE IF NOT EXISTS User (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(20),
        email VARCHAR(30),
        password VARCHAR(128)
    )
"""
)

# Leer el archivo JSON
with open("usuarios.json", "r") as f:
    usuarios = json.load(f)["usuarios"]

# Insertar usuarios
for user in usuarios:
    # Hashear la contraseña con bcrypt
    hashed_password = generate_password_hash(user["password"] + "library")

    # Usar consulta parametrizada para prevenir inyección SQL
    cur.execute(
        """
        INSERT INTO User (name, email, password) 
        VALUES (?, ?, ?)
        """,
        (user['nombres'], user['email'], hashed_password)
    )

# Confirmar todos los cambios
con.commit()
con.close()

print("Datos cargados correctamente en la base de datos.")
