from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
import sqlite3

app = Flask(__name__, static_url_path='', static_folder='../view/static',template_folder='../view/')
app.secret_key = 'your_secret_key'  # Cambia esto por una clave secreta más segura

# Conexión a la base de datos
def get_db_connection():
    conn = sqlite3.connect('datos.db')
    conn.row_factory = sqlite3.Row  # Esto te permite acceder a las columnas por nombre
    return conn



@app.route('/')
def index():
    # Comprobamos si el usuario está logueado y pasamos el nombre del usuario a la plantilla
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('index.html', username=user['name'])
    return render_template('index.html', username=None)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Comprobamos las credenciales del usuario
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE email = ?', (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password + "library"):  # Asegúrate de añadir el "salt"
            session['user_id'] = user['id']        # Guardamos el ID del usuario en la sesión
            session['user_name'] = user['name']    # Guardamos el nombre del usuario en la sesión
            flash('Has iniciado sesión correctamente.', 'success')
            return redirect(url_for('index'))
        else:
            flash('Email o contraseña incorrectos.', 'error')

    return render_template("login.html")

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('Has cerrado sesión.', 'info')
    return redirect(url_for('index'))

@app.route('/about')
def about():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('about.html', username=user['name'])
    return render_template('about.html', username=None)
    

@app.route('/feature')
def feature():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('feature.html', username=user['name'])
    return render_template('feature.html', username=None)
    

@app.route('/class')
def class_page():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('class.html', username=user['name'])
    return render_template('class.html', username=None)

@app.route('/blog')
def blog():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('blog.html', username=user['name'])
    return render_template('blog.html', username=None)

@app.route('/single')
def single():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('single.html', username=user['name'])
    return render_template('single.html', username=None)

@app.route('/contact')
def contact():
    if 'user_id' in session:
        user_id = session['user_id']
        user_name = session.get('user_name') 
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM User WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        return render_template('contact.html', username=user['name'])
    return render_template('contact.html', username=None)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
